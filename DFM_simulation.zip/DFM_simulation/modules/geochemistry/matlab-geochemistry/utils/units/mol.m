function [ d ] = mol(  )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
d = 1;


end

