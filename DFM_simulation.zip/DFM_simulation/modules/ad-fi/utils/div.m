function g = div(varargin)
g = grad(varargin{:}).';
end
