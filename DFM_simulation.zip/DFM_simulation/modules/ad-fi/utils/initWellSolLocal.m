function wellSol = initWellSolLocal(W, x)
%Initialize well solution data structure.
%
% SYNOPSIS:
%   wellSol = initWellSol(W, p0)
%
% DESCRIPTION:
%   Initialize the well solution structure to uniform well bottom-hole
%   pressures and all-zero well rates.
%
% PARAMETERS:
%   W  - Well data structure as defined by addWell &c.
%   p0 - Initial uniform well bottom-hole pressure (scalar).
%
% RETURNS:
%   wellSol - Initialized reservoir solution structure having fields
%               - flux     -- Well rates in all perforations (== 0).
%               - pressure -- Well bottom-hole pressure (== p0).
%
% SEE ALSO:
%   initResSol, solveIncompFlow.

%{
Copyright 2009, 2010, 2011, 2012 SINTEF ICT, Applied Mathematics.

This file is part of The MATLAB Reservoir Simulation Toolbox (MRST).

MRST is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

MRST is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with MRST.  If not, see <http://www.gnu.org/licenses/>.
%}

% $Date: 2011-07-01 14:30:35 +0200 (fr, 01 jul 2011) $
% $Revision: 7955 $

nW = numel(W);
wellSol = repmat(struct('flux',     [],...
                        'pressure', [],...
                        'qWs',      [],...
                        'qOs',      [],...
                        'qGs',      [],...
                        'poly',     []), [1, nW]);

if ~isstruct(x)
    for w = 1 : nW,
        wellSol(w).qWs      = 0;
        wellSol(w).qOs      = 0;
        wellSol(w).qGs      = 0;
        wellSol(w).pressure = x;%repmat(p0, [numel(W(w).cells), 1]);
    end
elseif isstruct(x) %state
    if isfield(x, 'wellSol')
        if numel(W)~=numel(x.wellSol)
            warning('Number of wells has changed, wellsol field should be updated based on well-name matching')
            for w = 1 : nW,
                wellSol(w).qWs      = 0;
                wellSol(w).qOs      = 0;
                wellSol(w).qGs      = 0;
                if W(w).sign == -1
                    limit = @min;
                else
                    limit = @max;
                end
                if isfield(W, 'bhpLimit')
                    wellSol(w).pressure = limit(x.pressure(W(w).cells(1)) + W(w).sign*10*barsa, W(w).bhpLimit - sqrt(eps));
                else
                    wellSol(w).pressure = x.pressure(W(w).cells(1)) + W(w).sign*10*barsa;
                end
            end
        else
            wellSol = x.wellSol;
        end
    else
        for w = 1 : nW,
            wellSol(w).qWs      = 0;
            wellSol(w).qOs      = 0;
            wellSol(w).qGs      = 0;
            wellSol(w).poly     = 0;
            if W(w).sign == -1
                limit = @min;
            else
                limit = @max;
            end
            if isfield(W, 'bhpLimit')
                wellSol(w).pressure = limit(x.pressure(W(w).cells(1)) + W(w).sign*10*barsa, W(w).bhpLimit - sqrt(eps));
            else
                wellSol(w).pressure = x.pressure(W(w).cells(1)) + W(w).sign*10*barsa;
            end
        end
    end
end
end
