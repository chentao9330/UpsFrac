% Files
%  eclOut2mrst      - full grid to active grid mapping
%  readFieldUnFmt   - Extract next field from an unformatted ECLIPSE output file
%  readSummaryLocal - estimate number of ministeps
%  smryGUI          - SMRYGUI M-file for smryGUI.fig

%{
#COPYRIGHT#
%}
