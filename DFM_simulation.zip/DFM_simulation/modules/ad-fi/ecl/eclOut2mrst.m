function [G, rock, N, T] = eclOut2mrst(init, grid)
units = {'metric', 'field', 'lab'};
unit  = units{init.INTEHEAD.values(3)};
u     = getUnitFacs(unit);

cartDims = grid.GRIDHEAD.values(2:4)';
actNum   = and(grid.ACTNUM.values, init.PORV.values > 0);


grdecl = struct('cartDims', cartDims, ...
                'COORD'   , convertFrom(grid.COORD.values, u.length), ...
                'ZCORN'   , convertFrom(grid.ZCORN.values, u.length), ...
                'ACTNUM'  , actNum );

G = processGRDECL(grdecl, 'SplitDisconnected', false);  
G = computeGeometry(G);
G.cells.centroids(:,3) = convertFrom(init.DEPTH.values, u.length);
G.PORV  = convertFrom(init.PORV.values(actNum), u.volume);
G.DX    = convertFrom(init.DX.values, u.length);
G.DY    = convertFrom(init.DY.values, u.length);
G.DZ    = convertFrom(init.DZ.values, u.length);

rock.poro = init.PORO.values;
rock.ntg  = init.NTG.values;
rock.perm = convertFrom([init.PERMX.values, init.PERMX.values, init.PERMX.values], u.perm);

[N, T] = getTrans(init, grid, actNum, cartDims);
T      = convertFrom(T, u.trans);

end


function u = getUnitFacs(unit)
switch unit
    case 'metric'
        u.length  = meter;
        u.volume  = meter^3;
        u.perm    = milli*darcy;
        u.trans   = centi*poise * meter^3 / (day * barsa);
    case 'field'
        u.length  = ft;
        u.volume  = ft^3;
        u.perm    = milli*darcy;
        u.trans   = centi*poise * stb / (day * psia);
    case 'lab'
        u.length  = centi*meter;
        u.volume  = (centi*meter)^3;
        u.perm    = milli*darcy;
        u.trans   = centi*poise * (centi*meter)^3 / (hour * atm);
    otherwise
        error(['Unknown unit:', unit])
end
end

function [N, T] = getTrans(init, grid, actNum, cartDims)
nCells = nnz(actNum); 

%full grid to active grid mapping 
actInx = zeros(prod(cartDims), 1); 
actInx(actNum) = (1:nCells)';

% temporary matrix M to find indices of active neighbors in X, Y and Z-direction,
M = zeros(cartDims+1);
M(1:end-1, 1:end-1, 1:end-1) = reshape(actInx, cartDims);

NX = M(2:end, 1:end-1, 1:end-1); NX = NX(actNum);
NY = M(1:end-1, 2:end, 1:end-1); NY = NY(actNum);
NZ = M(1:end-1, 1:end-1, 2:end); NZ = NZ(actNum);
  
%non-neighbouring connections (indices given in full grid -> map to active):
if isfield(init, 'TRANNNC')
    NNC1    = actInx(grid.NNC1.values);
    NNC2 	= actInx(grid.NNC2.values);
    TRANNNC = init.TRANNNC.values;
else
    NNC1    = [];
    NNC2 	= [];
    TRANNNC = [];
end
    

% produce neighbour list N, and transmissibilities T
N = [(1:nCells)' NX; ...
     (1:nCells)' NY; ...
     (1:nCells)' NZ; ...
     NNC1 NNC2];
T = [init.TRANX.values; ...
     init.TRANY.values; ...
     init.TRANZ.values; ...
     TRANNNC];
 
% remove 0-transmissibilities and non-active neighbors (appearing as zeros)
inx = and(T>0, prod(N,2)>0);
N = N(inx,:);
T = T(inx);
end