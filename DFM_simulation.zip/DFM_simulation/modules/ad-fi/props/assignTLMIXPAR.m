function f = assignTLMIXPAR(f, tlmixpar, reg)
f.mixPar = tlmixpar(1);
