function f = assignPLYMAX(f, plymax, reg)
f.cmax = plymax(1);
