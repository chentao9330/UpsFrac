% Files
%  basisOW   - function phi = basisOW(states, varargin), efrac_p, efrac_s, n_p, n_s)
%  createPod - [V,S,W] = svd(X);  bruk econ?

%{
#COPYRIGHT#
%}
