% Files
%  initEclipseGrid - Construct MRST grid from ECLIPSE GRID section.

%{
#COPYRIGHT#
%}
