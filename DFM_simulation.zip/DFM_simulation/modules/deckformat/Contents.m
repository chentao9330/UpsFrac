% ECLIPSE Support for reading/writing ECLIPSE input/output
