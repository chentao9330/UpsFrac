% Files
%  compressRock    - Compress rock properties to active cells only
%  initEclipseRock - Extract rock properties from input deck

%{
#COPYRIGHT#
%}
