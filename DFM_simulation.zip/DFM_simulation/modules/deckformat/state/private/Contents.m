% Files
%  direct_assignment - Initialisation through direct assignment of initial conditions.
%  equilibration     - Equilibration facility to handle EQUIL keyword.

%{
#COPYRIGHT#
%}
