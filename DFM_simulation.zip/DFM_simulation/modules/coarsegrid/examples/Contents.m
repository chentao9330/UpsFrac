% Files
%  simpleCoarseGridExample - Partition a Cartesian 2D grid

%{
#COPYRIGHT#
%}
