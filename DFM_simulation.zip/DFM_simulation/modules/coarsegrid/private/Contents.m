% Files
%  coarseConnections    - Derive connection/topology structure on coarse grid
%  transposeConnections - Derive block->connection (face) mapping from connection->block mapping

%{
#COPYRIGHT#
%}
