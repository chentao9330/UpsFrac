% Files
%  plotFaceOutline - PLOTFACEOUTLINE plots the outline of a selection of grid faces.
%  plotPatches     - Plot selection of coloured grid faces to current axes (reversed Z axis).

%{
#COPYRIGHT#
%}
