% Files
%  recovery  - recovery -- objective function calculating water volume at last time step
%  simpleNPV - Simple net-present-value function - no discount factor

%{
#COPYRIGHT#
%}
