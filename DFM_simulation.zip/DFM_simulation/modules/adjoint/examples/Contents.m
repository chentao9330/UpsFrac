% Files
%  compareGradients - compareGradients - compare gradients computed numerically and with adjoint
%  simpleBHPOpt     - simple adjoint test using BHP-control
%  simpleRateOpt    - simple adjoint test using rate - control

%{
#COPYRIGHT#
%}
