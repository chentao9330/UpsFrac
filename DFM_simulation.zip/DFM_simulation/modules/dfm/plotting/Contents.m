% Files
%  plotCellData_DFM - Plot exterior grid faces, coloured by given data, to current axes.
%  plotFaces_DFM    - Plot selection of coloured grid faces to current axes (reversed Z axis).
%  plotFractures    - SYNOPSIS:
%  plotGrid_DFM     - Plot exterior grid faces to current axes (reversed Z axis).

%{
#COPYRIGHT#
%}
