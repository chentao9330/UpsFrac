% Files
%  addFaces             - Add faces F from grid structure
%  copyFaces            - Copy face data for faces F from grid structure
%  emptyGrid            - Make empty grid.
%  insertInPackedData   - Insert c into row r of packed array (data, pos)
%  removeFaces          - Remove faces F from grid structure
%  removeFromPackedData - Remove all copies of specific elements from packed data structure
%  sortEdges            - Helper function to sortCellFaces

%{
#COPYRIGHT#
%}
